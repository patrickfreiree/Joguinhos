//código do ator
let yAtor = 362;
let xAtor = 100;
let colisao = false;
let meuPonto = 0;

function mostraAtor() {
  image(imagemDoAtor, 80, yAtor, 30, 30);
}

function movimentaAtor() {
  if (keyIsDown(UP_ARROW)) {
    yAtor -= 3;
  }
  if (keyIsDown(DOWN_ARROW)) {
    yAtor += 3;
  }
}

function verificaColisao() {
  
  //collideRectCircle(x1, y1 width1, heigth1, cx, cy, diameter)
  
  for (let i = 0; i < imagemCarros.length; i = i + 1) {
    colisao = collideRectCircle(
      xCarros[i],
      yCarros[i],
      comprimentoCarros,
      alturaCarros,
      xAtor,
      yAtor,
      15
    );
  }

  for (let i = 0; i < imagemMotos.length; i = i + 1) {
    colisao = collideRectCircle(
      xMotos[i],
      yMotos[i],
      comprimentoMotos,
      alturaMotos,
      xAtor,
      yAtor,
      15
    );

    if (colisao) {
      voltaPosicaoInicial();
    }
  }
}

function voltaPosicaoInicial() {
  yAtor = 366;
}

function incluiPontos() {
  textSize(25);
  textAlign(CENTER);
  fill(color(255, 225, 60));
  text(meuPonto, width / 5, 28);
}

function marcaPonto() {
  if (yAtor < 15) {
    meusPontos += 1;
    voltaPosicaoInicial();
  }
}