let imagemDaEstrada;
let imagemDoAtor;
let imagemCarro;
let imagemCarro2;
let imagemCarro3;
let imagemCarro4;
let imagemCarro5;
let imagemCarro6;
let imagemMoto;

function preload() {
  imagemDaEstrada = loadImage("imagem/estrada.png");
  imagemDoAtor = loadImage("imagem/zeus.png");
  imagemCarro = loadImage("imagem/carro-1.png");
  imagemCarro2 = loadImage("imagem/carro-2.png");
  imagemCarro3 = loadImage("imagem/carro-3.png");
  imagemCarro4 = loadImage("imagem/carro-1.png");
  imagemCarro5 = loadImage("imagem/carro-1.png");
  imagemCarro6 = loadImage("imagem/carro-2.png");
  imagemMoto = loadImage("imagem/moto.png");
  imagemMoto2 = loadImage("imagem/moto.png");
  imagemMoto3 = loadImage("imagem/moto.png");

  imagemCarros = [
    imagemCarro,
    imagemCarro2,
    imagemCarro3,
    imagemCarro4,
    imagemCarro5,
    imagemCarro6,
  ];
  imagemMotos = [imagemMoto, imagemMoto2, imagemMoto3];
}
